
# Long line for code smell analysis
def long_line_function():
    # FIXME: This line is way too long and should be broken up into multiple lines for better readability and to adhere to style guides like PEP 8.
    very_long_variable_name_that_is_used_to_demonstrate_a_very_long_line_of_code = "This is a string that makes the line even longer than it needs to be."
    return very_long_variable_name_that_is_used_to_demonstrate_a_very_long_line_of_code
