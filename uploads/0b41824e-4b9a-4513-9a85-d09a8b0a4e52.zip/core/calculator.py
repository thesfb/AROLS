
# High complexity function for complexity analysis
def complex_function(a, b, c, d, e):
    if a > b and (c < d or e == 1):
        if b > c and (d < e or a == 2):
            if c > d and (e < a or b == 3):
                if d > e and (a < b or c == 4):
                    return 100 # This is a magic number
    elif a == 5 or b == 6 or c == 7 or d == 8 or e == 9:
        return 200
    return 0
